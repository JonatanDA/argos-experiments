# Inicializador para hacer que la carpeta Observer sea un módulo de Python
